// This is a stub so that we don't have to install Trix
