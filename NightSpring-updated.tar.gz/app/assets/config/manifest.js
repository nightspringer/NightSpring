//= link_tree ../builds

// If you link assets from node_modules, don't forget to include them in config/initializers/assets.rb
//= link_tree ../../../node_modules/@fortawesome/fontawesome-free/webfonts
//= link_tree ../../../node_modules/@fontsource/lexend/files
