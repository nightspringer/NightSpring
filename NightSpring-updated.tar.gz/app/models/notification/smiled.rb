# frozen_string_literal: true

class Notification::Smiled < Notification
end
