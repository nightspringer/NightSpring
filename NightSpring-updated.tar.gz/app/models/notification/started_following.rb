# frozen_string_literal: true

class Notification::StartedFollowing < Notification
end
