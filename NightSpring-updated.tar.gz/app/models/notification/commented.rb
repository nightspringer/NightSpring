# frozen_string_literal: true

class Notification::Commented < Notification
end
