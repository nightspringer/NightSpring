# frozen_string_literal: true

class Notification::QuestionAnswered < Notification
end
