# frozen_string_literal: true

class Notification::PushSubscriptionError < Notification
end
