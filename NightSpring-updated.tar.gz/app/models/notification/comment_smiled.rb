# frozen_string_literal: true

class Notification::CommentSmiled < Notification
end
