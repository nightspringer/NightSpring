# frozen_string_literal: true

# NOTE: `target` is not really used for this notification, but it should be of type `User::DataExport`
class Notification::DataExported < Notification
end
