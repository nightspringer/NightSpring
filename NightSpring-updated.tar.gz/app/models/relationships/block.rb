# frozen_string_literal: true

class Relationships::Block < Relationship
end
