# frozen_string_literal: true

class Relationships::Mute < Relationship
end
