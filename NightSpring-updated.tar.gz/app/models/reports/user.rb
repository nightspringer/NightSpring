class Reports::User < Report
end