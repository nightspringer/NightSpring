class Reports::Answer < Report
end