class Reports::Comment < Report
end