class Reports::Question < Report
end