# frozen_string_literal: true

# stub model to nicely allow for data export notifications, do NOT use this directly!
class User::DataExport < User
end
