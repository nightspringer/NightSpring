# frozen_string_literal: true

module AjaxHelper
end
