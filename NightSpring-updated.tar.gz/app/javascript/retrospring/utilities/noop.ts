export default (): void => {
  // do nothing
}
