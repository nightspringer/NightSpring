Devise::Async.enabled = true
