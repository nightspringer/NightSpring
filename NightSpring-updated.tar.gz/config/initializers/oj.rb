Oj.optimize_rails
