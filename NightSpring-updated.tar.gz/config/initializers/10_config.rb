# frozen_string_literal: true

# Auxiliary config
APP_CONFIG = NightSpring::Config.config_hash
